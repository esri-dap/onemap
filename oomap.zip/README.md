## Custom Portal - Inspired by Netflix Slider

DEMO
https://esri-dap.github.io/portal-flixstyle/
